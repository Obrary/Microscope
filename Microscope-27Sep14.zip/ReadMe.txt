Product: Microscope, September 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/designs/microscope

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Here's a low cost teaching microscope designed to be built and used by students to learn microscopy. Depending on your choice of lenses, this can cost between $0.40 and $3.50 per microscope. 